<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;
use Mail;
use App\Mail\SendLinks;
use Illuminate\Support\Facades\Crypt;
use App\Models\User;

	class HomeController extends Controller{

		/*public function __construct()
    {
      $this->middleware('auth', ['only' => ['index','saveVote','getCongregation','getCongregationBasedUsers','listUsers', 'listAllUsers', 'editUser', 'updateUser', 'sendManualReminderEmail','phase_two','savePhaseTwo','phase_three','savePhaseThree']]);
    }*/

    public function index()
    {
    	$data['tcount'] = 5;
    	$data['ausers'] = User::whereNotIn('id', [2])->get();
    	$data['my_details'] = User::where('id',@Auth::user()->id)->get();
    	return view('dashboard',$data);
    }

    public function saveVote(Request $request)
    {
    	$data = $this->validate($request, [
                  "mjsuperior.*" => 'required|integer'
              ]);
    	/*Update my vote Count Starts*/
      $user = User::findOrFail(Auth::user()->id);
      if($user->voted == 1){
        return redirect()->back()->with('error', 'Sorry, You have already voted !');  
      } else {
        $vdata['voted'] = 1;//Auth::user()->id;
        $vdata['voted_dtime'] = date('Y-m-d H:i:s');
        
        $u1 = $user->update($vdata);
        /*Update my vote Count Ends*/

        /*Update/Insert new vote to users Starts*/
        foreach($request->all()['mjsuperior'] as $mjskey => $mjsval){
          $fcuser = User::findOrFail($mjsval);
          $voteData['votecnt'] = $fcuser->votecnt + 1;
          $u2 = $fcuser->update($voteData);
        }
        /*Update/Insert new vote to users Ends*/
        if($u1 && $u2){
          return redirect()->back()->with('success', 'Thanks for voting');  
        } else {
          return redirect()->back()->with('error', 'Sorry, Techincal Issue... Please Try Later !');  
        }
      }
    }

		public function sendEmailLink(){
			$users = User::whereNotIn('id', [2,5,6,7,8,9,3,4])->get();
			foreach ($users as $ukey => $user) {
					$mdata = [
					'name' => $user->name,
					'role' => 'Fr ',
					'message' => 'Greetings from the Election Commision of Indian Mission Vicariate. Please choose Six delegates to the Ⅳ-IMV Chapter '.date('Y').' according to your prefrence.',
					'note' => 'The software will not reveal your identity. It will simply total the votes.',
					'sipurl' => 'user-login/'.Crypt::encryptString(base64_encode($user->email).'/CRI/'.base64_encode('admin@123'))
				];

				$fuser = User::findOrFail($user->id);
        try{
          Mail::to(trim($user->email))->send(new SendLinks($mdata));
          $data['p1_email'] = 1;
          $data['p1_email_sent_at'] = date('Y-m-d H:i:s');
          $fuser->update($data);
        }
        catch(Exception $e){
          // Never reached
          if(count(Mail::failures()) > 0) {
            $data['p1_email']=0;
            $fuser->update($data);
            $failures_musers[] = $user->email;
          }
          print_r($user->email);exit;
        }
			}
			

			return "Email sent successfully!";
		}
	}
?>